using UniversityApi.Models;

namespace UniversityApi.Repositories.Interfaces;

public interface IStudentRepository : IRepository<Student>
{
    Task<Student?> GetWithCoursesAsync(int id, CancellationToken cancellationToken = default);
    Task<bool> EmailExistsAsync(string email, int? exceptId = null, CancellationToken cancellationToken = default);
}
public interface ITeacherRepository : IRepository<Teacher>
{
    Task<bool> EmailExistsAsync(string email, int? exceptId = null, CancellationToken cancellationToken = default);
}
public interface ICourseRepository : IRepository<Course>
{
    Task<bool> TeacherExistsAsync(int teacherId, CancellationToken cancellationToken = default);
    Task<List<Course>> SearchAsync(string? name, int? teacherId, int? minCredits, int? maxCredits, CancellationToken cancellationToken = default);
}
public interface IEnrollmentRepository : IRepository<Enrollment>
{
    Task<bool> StudentExistsAsync(int studentId, CancellationToken cancellationToken = default);
    Task<bool> CourseExistsAsync(int courseId, CancellationToken cancellationToken = default);
    Task<bool> AlreadyEnrolledAsync(int studentId, int courseId, int? exceptId = null, CancellationToken cancellationToken = default);
}
