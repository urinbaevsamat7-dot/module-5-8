using Microsoft.EntityFrameworkCore;
using UniversityApi.Data;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Repositories.Implementations;

public class Repository<TEntity>(ApplicationDbContext db) : IRepository<TEntity> where TEntity : class
{
    protected readonly ApplicationDbContext Db = db;
    protected readonly DbSet<TEntity> Set = db.Set<TEntity>();

    public virtual Task<List<TEntity>> GetAllAsync(CancellationToken cancellationToken = default) =>
        Set.AsNoTracking().ToListAsync(cancellationToken);
    public virtual Task<TEntity?> GetByIdAsync(int id, CancellationToken cancellationToken = default) =>
        Set.FindAsync(new object[] { id }, cancellationToken).AsTask();
    public virtual async Task AddAsync(TEntity entity, CancellationToken cancellationToken = default)
    {
        await Set.AddAsync(entity, cancellationToken);
    }
    public virtual void Update(TEntity entity) => Set.Update(entity);
    public virtual void Delete(TEntity entity) => Set.Remove(entity);
    public virtual Task SaveChangesAsync(CancellationToken cancellationToken = default) =>
        Db.SaveChangesAsync(cancellationToken);
}
