using Microsoft.AspNetCore.Identity;
using UniversityApi.Models;

namespace UniversityApi.Data;

public static class IdentitySeeder
{
    private static readonly string[] Roles = ["Admin", "Teacher", "Student"];

    public static async Task SeedAsync(IServiceProvider services, IConfiguration configuration, ILogger logger)
    {
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();
        foreach (var role in Roles)
        {
            if (!await roleManager.RoleExistsAsync(role))
            {
                var created = await roleManager.CreateAsync(new IdentityRole(role));
                if (!created.Succeeded) throw new InvalidOperationException($"Could not create role {role}.");
            }
        }

        var userName = configuration["SeedAdmin:UserName"];
        var email = configuration["SeedAdmin:Email"];
        var password = configuration["SeedAdmin:Password"];
        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            logger.LogInformation("Admin account seeding skipped. Configure SeedAdmin credentials through user-secrets or environment variables for a local demo.");
            return;
        }

        var admin = await userManager.FindByNameAsync(userName);
        if (admin is null)
        {
            admin = new ApplicationUser { UserName = userName, Email = email, EmailConfirmed = true, LockoutEnabled = true };
            var created = await userManager.CreateAsync(admin, password);
            if (!created.Succeeded)
                throw new InvalidOperationException("Admin account could not be created. Check the configured password against Identity requirements.");
        }
        if (!await userManager.IsInRoleAsync(admin, "Admin"))
        {
            var result = await userManager.AddToRoleAsync(admin, "Admin");
            if (!result.Succeeded) throw new InvalidOperationException("Could not assign Admin role to the configured seed account.");
        }
    }
}
