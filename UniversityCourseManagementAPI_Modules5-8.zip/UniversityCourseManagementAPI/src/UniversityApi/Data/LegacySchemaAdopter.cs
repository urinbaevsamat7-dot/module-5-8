using System.Data;
using Microsoft.EntityFrameworkCore;

namespace UniversityApi.Data;

/// <summary>Registers the original EnsureCreated schema as the initial migration so existing student databases can be upgraded.</summary>
public static class LegacySchemaAdopter
{
    public static async Task AdoptIfNeededAsync(ApplicationDbContext db, CancellationToken ct = default)
    {
        var connection = db.Database.GetDbConnection();
        var openedHere = connection.State != ConnectionState.Open;
        if (openedHere) await connection.OpenAsync(ct);
        try
        {
            await using var check = connection.CreateCommand();
            check.CommandText = "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'Students')";
            var hasStudents = (bool)(await check.ExecuteScalarAsync(ct) ?? false);
            if (!hasStudents) return;

            await using var historyCheck = connection.CreateCommand();
            historyCheck.CommandText = "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = '__EFMigrationsHistory')";
            var hasHistory = (bool)(await historyCheck.ExecuteScalarAsync(ct) ?? false);
            if (hasHistory)
            {
                await using var initialCheck = connection.CreateCommand();
                initialCheck.CommandText = """SELECT EXISTS (SELECT 1 FROM "__EFMigrationsHistory" WHERE "MigrationId" = '20261016151739_InitialCreate')""";
                var hasInitial = (bool)(await initialCheck.ExecuteScalarAsync(ct) ?? false);
                if (hasInitial) return;
            }

            await using var adopt = connection.CreateCommand();
            adopt.CommandText = """
                CREATE TABLE IF NOT EXISTS "__EFMigrationsHistory" (
                    "MigrationId" character varying(150) NOT NULL PRIMARY KEY,
                    "ProductVersion" character varying(32) NOT NULL
                );
                INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
                VALUES ('20261016151739_InitialCreate', '8.0.11')
                ON CONFLICT ("MigrationId") DO NOTHING;
                """;
            await adopt.ExecuteNonQueryAsync(ct);
        }
        finally
        {
            if (openedHere) await connection.CloseAsync();
        }
    }
}
