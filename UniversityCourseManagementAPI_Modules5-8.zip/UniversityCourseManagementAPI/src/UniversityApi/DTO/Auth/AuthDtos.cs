using System.ComponentModel.DataAnnotations;

namespace UniversityApi.DTO.Auth;

public sealed class RegisterRequest
{
    [Required, StringLength(50, MinimumLength = 3)]
    public string UserName { get; set; } = string.Empty;
    [Required, EmailAddress, StringLength(160)]
    public string Email { get; set; } = string.Empty;
    [Required, StringLength(100, MinimumLength = 10)]
    public string Password { get; set; } = string.Empty;
    [Required, StringLength(80, MinimumLength = 1)]
    public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(80, MinimumLength = 1)]
    public string LastName { get; set; } = string.Empty;
    [Required]
    public DateTime BirthDate { get; set; }
}

public sealed class LoginRequest
{
    [Required]
    public string UserName { get; set; } = string.Empty;
    [Required]
    public string Password { get; set; } = string.Empty;
}

public sealed record AuthResponse(string AccessToken, string TokenType, DateTime ExpiresAtUtc, string UserName, string[] Roles);
public sealed record CurrentUserResponse(string Id, string? UserName, string? Email, string[] Roles, int? StudentId, int? TeacherId);

public sealed class AssignRoleRequest
{
    [Required]
    public string Role { get; set; } = string.Empty;
    public int? StudentId { get; set; }
    public int? TeacherId { get; set; }
}
