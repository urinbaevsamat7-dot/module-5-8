namespace UniversityApi.DTO.Versioning;

public sealed class CourseV2Dto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int Credits { get; set; }
    public int TeacherId { get; set; }
    public string? TeacherName { get; set; }
    public int EnrolledStudentCount { get; set; }
    public DateTime CreatedAt { get; set; }
}
