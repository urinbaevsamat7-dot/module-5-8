using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;

namespace UniversityApi.Controllers;

[ApiController]
public abstract class ApiControllerBase : ControllerBase
{
    protected IActionResult OkResult<T>(T? result) =>
        StatusCode(200, ReturnResult<T>.Success(result, 200, HttpContext.TraceIdentifier));

    protected IActionResult CreatedResult<T>(string actionName, object routeValues, T result) =>
        StatusCode(201, ReturnResult<T>.Success(result, 201, HttpContext.TraceIdentifier));

    protected IActionResult ErrorResult<T>(int status, string code, string message) =>
        StatusCode(status, ReturnResult<T>.Failure(status, code, message, HttpContext.TraceIdentifier));
}
