namespace UniversityApi.Common;

public class ReturnResult<T>
{
    public int StatusCode { get; init; }
    public bool IsSuccess { get; init; }
    public T? Result { get; init; }
    public string? ErrorCode { get; init; }
    public string? ErrorMessage { get; init; }
    public string? TraceId { get; init; }

    public static ReturnResult<T> Success(T? result, int statusCode = 200, string? traceId = null) =>
        new() { StatusCode = statusCode, IsSuccess = true, Result = result, TraceId = traceId };

    public static ReturnResult<T> Failure(int statusCode, string errorCode, string message, string? traceId = null) =>
        new() { StatusCode = statusCode, IsSuccess = false, ErrorCode = errorCode, ErrorMessage = message, TraceId = traceId };
}
