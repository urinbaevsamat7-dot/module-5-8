using AutoMapper;
using UniversityApi.DTO.Courses;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Services;

public interface ICourseService
{
    Task<List<CourseDto>> GetAllAsync(CancellationToken ct);
    Task<List<CourseDto>> SearchAsync(string? name, int? teacherId, int? minCredits, int? maxCredits, CancellationToken ct);
    Task<CourseDto?> GetByIdAsync(int id, CancellationToken ct);
    Task<(CourseDto? Value, string? Error)> CreateAsync(CourseCreateDto dto, CancellationToken ct);
    Task<(CourseDto? Value, string? Error)> UpdateAsync(int id, CourseUpdateDto dto, CancellationToken ct);
    Task<bool> DeleteAsync(int id, CancellationToken ct);
}
public sealed class CourseService(ICourseRepository repo, IMapper mapper, ILogger<CourseService> logger) : ICourseService
{
    public async Task<List<CourseDto>> GetAllAsync(CancellationToken ct) => mapper.Map<List<CourseDto>>(await repo.GetAllAsync(ct));
    public async Task<List<CourseDto>> SearchAsync(string? name, int? teacherId, int? minCredits, int? maxCredits, CancellationToken ct) =>
        mapper.Map<List<CourseDto>>(await repo.SearchAsync(name, teacherId, minCredits, maxCredits, ct));
    public async Task<CourseDto?> GetByIdAsync(int id, CancellationToken ct) => mapper.Map<CourseDto?>(await repo.GetByIdAsync(id, ct));
    public async Task<(CourseDto? Value, string? Error)> CreateAsync(CourseCreateDto dto, CancellationToken ct)
    {
        if (!await repo.TeacherExistsAsync(dto.TeacherId, ct)) return (null, "TEACHER_NOT_FOUND");
        var entity = mapper.Map<Course>(dto); await repo.AddAsync(entity, ct); await repo.SaveChangesAsync(ct);
        entity = await repo.GetByIdAsync(entity.Id, ct) ?? entity;
        logger.LogInformation("Created course {CourseId}", entity.Id);
        return (mapper.Map<CourseDto>(entity), null);
    }
    public async Task<(CourseDto? Value, string? Error)> UpdateAsync(int id, CourseUpdateDto dto, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Course {CourseId} not found for update", id); return (null, "NOT_FOUND"); }
        if (!await repo.TeacherExistsAsync(dto.TeacherId, ct)) return (null, "TEACHER_NOT_FOUND");
        mapper.Map(dto, entity); repo.Update(entity); await repo.SaveChangesAsync(ct);
        entity = await repo.GetByIdAsync(id, ct) ?? entity;
        logger.LogInformation("Updated course {CourseId}", id);
        return (mapper.Map<CourseDto>(entity), null);
    }
    public async Task<bool> DeleteAsync(int id, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Course {CourseId} not found for delete", id); return false; }
        repo.Delete(entity); await repo.SaveChangesAsync(ct); logger.LogInformation("Deleted course {CourseId}", id); return true;
    }
}
