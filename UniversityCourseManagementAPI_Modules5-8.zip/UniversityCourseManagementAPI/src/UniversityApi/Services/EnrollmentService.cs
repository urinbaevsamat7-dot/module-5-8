using AutoMapper;
using UniversityApi.DTO.Enrollments;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Services;

public interface IEnrollmentService
{
    Task<List<EnrollmentDto>> GetAllAsync(CancellationToken ct);
    Task<EnrollmentDto?> GetByIdAsync(int id, CancellationToken ct);
    Task<(EnrollmentDto? Value, string? Error)> CreateAsync(EnrollmentCreateDto dto, CancellationToken ct);
    Task<(EnrollmentDto? Value, string? Error)> UpdateGradeAsync(int id, EnrollmentGradeUpdateDto dto, CancellationToken ct);
    Task<bool> DeleteAsync(int id, CancellationToken ct);
}
public sealed class EnrollmentService(IEnrollmentRepository repo, IMapper mapper, ILogger<EnrollmentService> logger) : IEnrollmentService
{
    public async Task<List<EnrollmentDto>> GetAllAsync(CancellationToken ct) => mapper.Map<List<EnrollmentDto>>(await repo.GetAllAsync(ct));
    public async Task<EnrollmentDto?> GetByIdAsync(int id, CancellationToken ct) => mapper.Map<EnrollmentDto?>(await repo.GetByIdAsync(id, ct));
    public async Task<(EnrollmentDto? Value, string? Error)> CreateAsync(EnrollmentCreateDto dto, CancellationToken ct)
    {
        if (!await repo.StudentExistsAsync(dto.StudentId, ct)) return (null, "STUDENT_NOT_FOUND");
        if (!await repo.CourseExistsAsync(dto.CourseId, ct)) return (null, "COURSE_NOT_FOUND");
        if (await repo.AlreadyEnrolledAsync(dto.StudentId, dto.CourseId, null, ct)) return (null, "ENROLLMENT_ALREADY_EXISTS");
        var entity = mapper.Map<Enrollment>(dto); await repo.AddAsync(entity, ct); await repo.SaveChangesAsync(ct);
        entity = await repo.GetByIdAsync(entity.Id, ct) ?? entity;
        logger.LogInformation("Created enrollment {EnrollmentId} for student {StudentId}, course {CourseId}", entity.Id, dto.StudentId, dto.CourseId);
        return (mapper.Map<EnrollmentDto>(entity), null);
    }
    public async Task<(EnrollmentDto? Value, string? Error)> UpdateGradeAsync(int id, EnrollmentGradeUpdateDto dto, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Enrollment {EnrollmentId} not found for grade update", id); return (null, "NOT_FOUND"); }
        entity.Grade = dto.Grade; repo.Update(entity); await repo.SaveChangesAsync(ct);
        entity = await repo.GetByIdAsync(id, ct) ?? entity;
        logger.LogInformation("Updated grade for enrollment {EnrollmentId}", id);
        return (mapper.Map<EnrollmentDto>(entity), null);
    }
    public async Task<bool> DeleteAsync(int id, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Enrollment {EnrollmentId} not found for delete", id); return false; }
        repo.Delete(entity); await repo.SaveChangesAsync(ct); logger.LogInformation("Deleted enrollment {EnrollmentId}", id); return true;
    }
}
