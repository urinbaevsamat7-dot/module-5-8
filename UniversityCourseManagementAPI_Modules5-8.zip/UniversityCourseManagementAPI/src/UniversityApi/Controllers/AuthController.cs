using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Common;
using UniversityApi.Data;
using UniversityApi.DTO.Auth;
using UniversityApi.Models;
using UniversityApi.Security;

namespace UniversityApi.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(
    UserManager<ApplicationUser> userManager,
    SignInManager<ApplicationUser> signInManager,
    ApplicationDbContext db,
    TokenService tokenService,
    ILogger<AuthController> logger) : ControllerBase
{
    [AllowAnonymous]
    [HttpPost("register")]
    public async Task<IActionResult> Register(RegisterRequest request, CancellationToken ct)
    {
        var normalizedEmail = request.Email.Trim().ToLowerInvariant();
        if (await db.Students.AnyAsync(s => s.Email.ToLower() == normalizedEmail, ct))
            return Conflict(ReturnResult<object>.Failure(409, "EMAIL_ALREADY_EXISTS", "A student with this email already exists.", HttpContext.TraceIdentifier));
        var user = new ApplicationUser
        {
            UserName = request.UserName.Trim(),
            Email = normalizedEmail,
            EmailConfirmed = false,
            LockoutEnabled = true
        };
        var create = await userManager.CreateAsync(user, request.Password);
        if (!create.Succeeded)
        {
            var errors = create.Errors.Select(e => e.Code == "DuplicateUserName"
                ? "Username is already taken." : e.Description).ToArray();
            return StatusCode(400, ReturnResult<string[]>.Failure(400, "REGISTRATION_FAILED",
                string.Join(" ", errors), HttpContext.TraceIdentifier));
        }

        try
        {
            var student = new Student
            {
                FirstName = request.FirstName.Trim(),
                LastName = request.LastName.Trim(),
                Email = user.Email!,
                BirthDate = DateTime.SpecifyKind(request.BirthDate.Date, DateTimeKind.Utc),
                CreatedAt = DateTime.UtcNow
            };
            db.Students.Add(student);
            await db.SaveChangesAsync(ct);
            user.StudentId = student.Id;
            var update = await userManager.UpdateAsync(user);
            if (!update.Succeeded) throw new InvalidOperationException("Could not link the new student profile.");
            var roleResult = await userManager.AddToRoleAsync(user, "Student");
            if (!roleResult.Succeeded) throw new InvalidOperationException("Could not assign the default Student role.");
        }
        catch
        {
            await userManager.DeleteAsync(user);
            throw;
        }

        logger.LogInformation("Registered new user account {UserId}", user.Id);
        return StatusCode(201, ReturnResult<object>.Success(new { user.Id, user.UserName, Message = "Registration successful. Sign in to obtain an access token." }, 201, HttpContext.TraceIdentifier));
    }

    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var user = await userManager.FindByNameAsync(request.UserName.Trim());
        if (user is null)
        {
            logger.LogWarning("Login failed for unknown username");
            return Unauthorized(ReturnResult<object>.Failure(401, "INVALID_CREDENTIALS", "Username or password is incorrect.", HttpContext.TraceIdentifier));
        }

        var signIn = await signInManager.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: true);
        if (!signIn.Succeeded)
        {
            logger.LogWarning("Login failed for user {UserId}; locked out: {LockedOut}", user.Id, signIn.IsLockedOut);
            return Unauthorized(ReturnResult<object>.Failure(401,
                signIn.IsLockedOut ? "ACCOUNT_LOCKED" : "INVALID_CREDENTIALS",
                signIn.IsLockedOut ? "The account is temporarily locked after repeated failed attempts." : "Username or password is incorrect.",
                HttpContext.TraceIdentifier));
        }

        var (token, expiresAt) = await tokenService.CreateAccessTokenAsync(user);
        var roles = (await userManager.GetRolesAsync(user)).ToArray();
        logger.LogInformation("User {UserId} signed in successfully", user.Id);
        return Ok(ReturnResult<AuthResponse>.Success(new AuthResponse(token, "Bearer", expiresAt, user.UserName!, roles), 200, HttpContext.TraceIdentifier));
    }

    [Authorize]
    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var id = userManager.GetUserId(User);
        if (id is null) return Unauthorized(ReturnResult<object>.Failure(401, "UNAUTHENTICATED", "A valid access token is required.", HttpContext.TraceIdentifier));
        var user = await userManager.FindByIdAsync(id);
        if (user is null) return Unauthorized(ReturnResult<object>.Failure(401, "USER_NOT_FOUND", "The account is no longer available.", HttpContext.TraceIdentifier));
        var roles = (await userManager.GetRolesAsync(user)).ToArray();
        return Ok(ReturnResult<CurrentUserResponse>.Success(
            new CurrentUserResponse(user.Id, user.UserName, user.Email, roles, user.StudentId, user.TeacherId), 200, HttpContext.TraceIdentifier));
    }
}
