using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Common;
using UniversityApi.Data;
using UniversityApi.DTO.Enrollments;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[ApiVersionNeutral]
[Route("api/[controller]")]
[Authorize]
public class EnrollmentsController(IEnrollmentService service, ApplicationDbContext db) : ApiControllerBase
{
    [HttpGet]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> GetAll(CancellationToken ct) => OkResult(await service.GetAllAsync(ct));

    [HttpGet("mine")]
    [Authorize(Roles = "Student,Teacher,Admin")]
    public async Task<IActionResult> GetMine(CancellationToken ct)
    {
        if (User.IsInRole("Admin")) return OkResult(await service.GetAllAsync(ct));
        var query = db.Enrollments.AsNoTracking().Include(e => e.Student).Include(e => e.Course).AsQueryable();
        if (User.IsInRole("Student"))
        {
            if (!int.TryParse(User.FindFirst("studentId")?.Value, out var studentId)) return Forbid();
            query = query.Where(e => e.StudentId == studentId);
        }
        else if (User.IsInRole("Teacher"))
        {
            if (!int.TryParse(User.FindFirst("teacherId")?.Value, out var teacherId)) return Forbid();
            query = query.Where(e => e.Course != null && e.Course.TeacherId == teacherId);
        }
        else return Forbid();
        var result = await query.Select(e => new EnrollmentDto
        {
            Id = e.Id, StudentId = e.StudentId, StudentName = e.Student == null ? null : e.Student.FirstName + " " + e.Student.LastName,
            CourseId = e.CourseId, CourseName = e.Course == null ? null : e.Course.Name, EnrollmentDate = e.EnrollmentDate, Grade = e.Grade
        }).ToListAsync(ct);
        return OkResult(result);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var enrollment = await db.Enrollments.AsNoTracking().Include(e => e.Course).FirstOrDefaultAsync(e => e.Id == id, ct);
        if (enrollment is null) return ErrorResult<EnrollmentDto>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found.");
        if (User.IsInRole("Admin")) return OkResult(await service.GetByIdAsync(id, ct));
        if (User.IsInRole("Student") && User.FindFirst("studentId")?.Value == enrollment.StudentId.ToString()) return OkResult(await service.GetByIdAsync(id, ct));
        if (User.IsInRole("Teacher") && User.FindFirst("teacherId")?.Value == enrollment.Course?.TeacherId.ToString()) return OkResult(await service.GetByIdAsync(id, ct));
        return Forbid();
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Create([FromBody] EnrollmentCreateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.CreateAsync(dto, ct);
        return error switch
        {
            "STUDENT_NOT_FOUND" => ErrorResult<EnrollmentDto>(404, error, "Student not found."),
            "COURSE_NOT_FOUND" => ErrorResult<EnrollmentDto>(404, error, "Course not found."),
            "ENROLLMENT_ALREADY_EXISTS" => ErrorResult<EnrollmentDto>(409, error, "This student is already enrolled in this course."),
            _ => StatusCode(201, ReturnResult<EnrollmentDto>.Success(value, 201, HttpContext.TraceIdentifier))
        };
    }

    [HttpPatch("{id:int}/grade")]
    [Authorize(Policy = "TeacherOrAdmin")]
    public async Task<IActionResult> UpdateGrade(int id, [FromBody] EnrollmentGradeUpdateDto dto, CancellationToken ct)
    {
        if (User.IsInRole("Teacher"))
        {
            if (!int.TryParse(User.FindFirst("teacherId")?.Value, out var teacherId)) return Forbid();
            var ownsCourse = await db.Enrollments.AsNoTracking().AnyAsync(e => e.Id == id && e.Course != null && e.Course.TeacherId == teacherId, ct);
            if (!ownsCourse) return Forbid();
        }
        var (value, error) = await service.UpdateGradeAsync(id, dto, ct);
        return error == "NOT_FOUND"
            ? ErrorResult<EnrollmentDto>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found.")
            : OkResult(value);
    }

    [HttpDelete("{id:int}")]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct) =>
        await service.DeleteAsync(id, ct) ? OkResult(new { message = "Enrollment deleted." }) :
            ErrorResult<object>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found.");
}
