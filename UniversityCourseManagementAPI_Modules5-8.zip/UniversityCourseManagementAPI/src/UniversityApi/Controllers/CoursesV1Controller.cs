using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Common;
using UniversityApi.Data;
using UniversityApi.DTO.Courses;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/courses")]
public sealed class CoursesV1Controller(ICourseService service) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> GetAll(CancellationToken ct) =>
        Ok(ReturnResult<List<CourseDto>>.Success(await service.GetAllAsync(ct), 200, HttpContext.TraceIdentifier));

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var course = await service.GetByIdAsync(id, ct);
        return course is null
            ? NotFound(ReturnResult<CourseDto>.Failure(404, "COURSE_NOT_FOUND", "Course not found.", HttpContext.TraceIdentifier))
            : Ok(ReturnResult<CourseDto>.Success(course, 200, HttpContext.TraceIdentifier));
    }
}
