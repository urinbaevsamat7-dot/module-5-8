using Asp.Versioning;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Common;
using UniversityApi.Data;
using UniversityApi.DTO.Versioning;

namespace UniversityApi.Controllers;

[ApiController]
[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/courses")]
public sealed class CoursesV2Controller(ApplicationDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> GetAll(CancellationToken ct)
    {
        var courses = await db.Courses.AsNoTracking().Include(c => c.Teacher)
            .Select(c => new CourseV2Dto
            {
                Id = c.Id, Name = c.Name, Description = c.Description, Credits = c.Credits,
                TeacherId = c.TeacherId,
                TeacherName = c.Teacher == null ? null : c.Teacher.FirstName + " " + c.Teacher.LastName,
                EnrolledStudentCount = c.Enrollments.Count,
                CreatedAt = c.CreatedAt
            }).OrderBy(c => c.Name).ToListAsync(ct);
        return Ok(ReturnResult<List<CourseV2Dto>>.Success(courses, 200, HttpContext.TraceIdentifier));
    }

    [HttpGet("{id:int}")]
    [AllowAnonymous]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var course = await db.Courses.AsNoTracking().Include(c => c.Teacher)
            .Where(c => c.Id == id)
            .Select(c => new CourseV2Dto
            {
                Id = c.Id, Name = c.Name, Description = c.Description, Credits = c.Credits,
                TeacherId = c.TeacherId,
                TeacherName = c.Teacher == null ? null : c.Teacher.FirstName + " " + c.Teacher.LastName,
                EnrolledStudentCount = c.Enrollments.Count,
                CreatedAt = c.CreatedAt
            }).FirstOrDefaultAsync(ct);
        return course is null
            ? NotFound(ReturnResult<CourseV2Dto>.Failure(404, "COURSE_NOT_FOUND", "Course not found.", HttpContext.TraceIdentifier))
            : Ok(ReturnResult<CourseV2Dto>.Success(course, 200, HttpContext.TraceIdentifier));
    }
}
