using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using UniversityApi.Common;
using UniversityApi.DTO.Teachers;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;
using AutoMapper;

namespace UniversityApi.Controllers;

[ApiVersionNeutral]
[Route("api/[controller]")]
[Authorize]
public class TeachersController(ITeacherRepository repo, IMapper mapper, ILogger<TeachersController> logger) : ApiControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll(CancellationToken ct) => OkResult(mapper.Map<List<TeacherDto>>(await repo.GetAllAsync(ct)));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Teacher {TeacherId} not found", id); return ErrorResult<TeacherDto>(404, "TEACHER_NOT_FOUND", "Teacher not found."); }
        return OkResult(mapper.Map<TeacherDto>(entity));
    }

    [HttpPost]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Create([FromBody] TeacherCreateDto dto, CancellationToken ct)
    {
        if (await repo.EmailExistsAsync(dto.Email, null, ct)) return ErrorResult<TeacherDto>(409, "EMAIL_ALREADY_EXISTS", "A teacher with this email already exists.");
        var entity = mapper.Map<Teacher>(dto); await repo.AddAsync(entity, ct); await repo.SaveChangesAsync(ct);
        logger.LogInformation("Created teacher {TeacherId}", entity.Id);
        return StatusCode(201, ReturnResult<TeacherDto>.Success(mapper.Map<TeacherDto>(entity), 201, HttpContext.TraceIdentifier));
    }

    [HttpPut("{id:int}")]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Update(int id, [FromBody] TeacherUpdateDto dto, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Teacher {TeacherId} not found for update", id); return ErrorResult<TeacherDto>(404, "TEACHER_NOT_FOUND", "Teacher not found."); }
        if (await repo.EmailExistsAsync(dto.Email, id, ct)) return ErrorResult<TeacherDto>(409, "EMAIL_ALREADY_EXISTS", "A teacher with this email already exists.");
        mapper.Map(dto, entity); repo.Update(entity); await repo.SaveChangesAsync(ct);
        logger.LogInformation("Updated teacher {TeacherId}", id);
        return OkResult(mapper.Map<TeacherDto>(entity));
    }

    [HttpDelete("{id:int}")]
    [Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Teacher {TeacherId} not found for delete", id); return ErrorResult<object>(404, "TEACHER_NOT_FOUND", "Teacher not found."); }
        if ((await repo.GetAllAsync(ct)).Any(t => t.Id == id) && await HasCourses(id, ct))
            return ErrorResult<object>(409, "TEACHER_HAS_COURSES", "Cannot delete a teacher who has courses.");
        repo.Delete(entity); await repo.SaveChangesAsync(ct); logger.LogInformation("Deleted teacher {TeacherId}", id);
        return OkResult(new { message = "Teacher deleted." });
    }

    private async Task<bool> HasCourses(int teacherId, CancellationToken ct)
    {
        // Query via EF navigation data is intentionally kept in repository boundary for this small educational example.
        var entity = await repo.GetByIdAsync(teacherId, ct);
        return entity?.Courses.Count > 0;
    }
}
