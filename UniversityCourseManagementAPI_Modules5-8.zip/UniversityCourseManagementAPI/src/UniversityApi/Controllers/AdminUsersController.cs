using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Common;
using UniversityApi.Data;
using UniversityApi.DTO.Auth;
using UniversityApi.Models;

namespace UniversityApi.Controllers;

[ApiController]
[Route("api/admin/users")]
[Authorize(Policy = "AdminOnly")]
public sealed class AdminUsersController(UserManager<ApplicationUser> userManager, ApplicationDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetUsers(CancellationToken ct)
    {
        var users = await userManager.Users.AsNoTracking()
            .Select(u => new { u.Id, u.UserName, u.Email, u.StudentId, u.TeacherId, u.LockoutEnd, u.AccessFailedCount })
            .ToListAsync(ct);
        var result = new List<object>();
        foreach (var item in users)
        {
            var account = await userManager.FindByIdAsync(item.Id);
            var roles = account is null ? Array.Empty<string>() : (await userManager.GetRolesAsync(account)).ToArray();
            result.Add(new { item.Id, item.UserName, item.Email, item.StudentId, item.TeacherId, item.LockoutEnd, item.AccessFailedCount, Roles = roles });
        }
        return Ok(ReturnResult<object>.Success(result, 200, HttpContext.TraceIdentifier));
    }

    [HttpPut("{userId}/role")]
    public async Task<IActionResult> AssignRole(string userId, AssignRoleRequest request, CancellationToken ct)
    {
        var currentUserId = userManager.GetUserId(User);
        if (string.Equals(currentUserId, userId, StringComparison.Ordinal))
            return StatusCode(403, ReturnResult<object>.Failure(403, "SELF_ROLE_CHANGE_FORBIDDEN", "Administrators cannot change their own roles through this endpoint.", HttpContext.TraceIdentifier));

        var allowedRoles = new[] { "Admin", "Teacher", "Student" };
        var role = allowedRoles.FirstOrDefault(r => string.Equals(r, request.Role, StringComparison.OrdinalIgnoreCase));
        if (role is null) return BadRequest(ReturnResult<object>.Failure(400, "INVALID_ROLE", "Role must be Admin, Teacher or Student.", HttpContext.TraceIdentifier));
        var user = await userManager.FindByIdAsync(userId);
        if (user is null) return NotFound(ReturnResult<object>.Failure(404, "USER_NOT_FOUND", "User not found.", HttpContext.TraceIdentifier));

        if (role == "Student")
        {
            if (!request.StudentId.HasValue || !await db.Students.AnyAsync(s => s.Id == request.StudentId.Value, ct))
                return BadRequest(ReturnResult<object>.Failure(400, "STUDENT_LINK_REQUIRED", "A valid StudentId is required for the Student role.", HttpContext.TraceIdentifier));
            user.StudentId = request.StudentId;
            user.TeacherId = null;
        }
        else if (role == "Teacher")
        {
            if (!request.TeacherId.HasValue || !await db.Teachers.AnyAsync(t => t.Id == request.TeacherId.Value, ct))
                return BadRequest(ReturnResult<object>.Failure(400, "TEACHER_LINK_REQUIRED", "A valid TeacherId is required for the Teacher role.", HttpContext.TraceIdentifier));
            user.TeacherId = request.TeacherId;
            user.StudentId = null;
        }
        else
        {
            user.StudentId = null;
            user.TeacherId = null;
        }

        var existing = await userManager.GetRolesAsync(user);
        var remove = await userManager.RemoveFromRolesAsync(user, existing);
        if (!remove.Succeeded) return BadRequest(ReturnResult<object>.Failure(400, "ROLE_UPDATE_FAILED", "Could not remove existing roles.", HttpContext.TraceIdentifier));
        var updateUser = await userManager.UpdateAsync(user);
        if (!updateUser.Succeeded) return BadRequest(ReturnResult<object>.Failure(400, "USER_UPDATE_FAILED", "Could not update user profile links.", HttpContext.TraceIdentifier));
        var add = await userManager.AddToRoleAsync(user, role);
        if (!add.Succeeded) return BadRequest(ReturnResult<object>.Failure(400, "ROLE_UPDATE_FAILED", "Could not assign the requested role.", HttpContext.TraceIdentifier));
        return Ok(ReturnResult<object>.Success(new { user.Id, user.UserName, Role = role, user.StudentId, user.TeacherId }, 200, HttpContext.TraceIdentifier));
    }

    [HttpPost("{userId}/lockout")]
    public async Task<IActionResult> Lockout(string userId, CancellationToken ct)
    {
        var user = await userManager.FindByIdAsync(userId);
        if (user is null) return NotFound(ReturnResult<object>.Failure(404, "USER_NOT_FOUND", "User not found.", HttpContext.TraceIdentifier));
        await userManager.SetLockoutEnabledAsync(user, true);
        await userManager.SetLockoutEndDateAsync(user, DateTimeOffset.UtcNow.AddHours(24));
        return Ok(ReturnResult<object>.Success(new { user.Id, Message = "Account locked for 24 hours." }, 200, HttpContext.TraceIdentifier));
    }
}
