using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using UniversityApi.Models;

namespace UniversityApi.Security;

public sealed class TokenService(IConfiguration configuration, UserManager<ApplicationUser> userManager)
{
    public async Task<(string Token, DateTime ExpiresAtUtc)> CreateAccessTokenAsync(ApplicationUser user)
    {
        var key = configuration["Jwt:Key"] ?? throw new InvalidOperationException("JWT signing key is not configured.");
        var issuer = configuration["Jwt:Issuer"] ?? "UniversityApi";
        var audience = configuration["Jwt:Audience"] ?? "UniversityApi.Clients";
        var minutes = int.TryParse(configuration["Jwt:AccessTokenMinutes"], out var configuredMinutes)
            ? Math.Clamp(configuredMinutes, 5, 60) : 20;
        var now = DateTime.UtcNow;
        var expires = now.AddMinutes(minutes);
        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id),
            new(ClaimTypes.NameIdentifier, user.Id),
            new(ClaimTypes.Name, user.UserName ?? user.Email ?? user.Id),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        };
        if (user.StudentId.HasValue) claims.Add(new Claim("studentId", user.StudentId.Value.ToString()));
        if (user.TeacherId.HasValue) claims.Add(new Claim("teacherId", user.TeacherId.Value.ToString()));
        foreach (var role in await userManager.GetRolesAsync(user)) claims.Add(new Claim(ClaimTypes.Role, role));

        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)), SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(issuer, audience, claims, now, expires, credentials);
        return (new JwtSecurityTokenHandler().WriteToken(token), expires);
    }
}
