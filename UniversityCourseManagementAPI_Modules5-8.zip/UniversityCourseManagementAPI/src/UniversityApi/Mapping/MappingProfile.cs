using AutoMapper;
using UniversityApi.DTO.Courses;
using UniversityApi.DTO.Enrollments;
using UniversityApi.DTO.Students;
using UniversityApi.DTO.Teachers;
using UniversityApi.Models;

namespace UniversityApi.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<Student, StudentDto>();
        CreateMap<StudentCreateDto, Student>().ForMember(x => x.Id, o => o.Ignore())
            .ForMember(x => x.CreatedAt, o => o.MapFrom(_ => DateTime.UtcNow));
        CreateMap<StudentUpdateDto, Student>().ForMember(x => x.Id, o => o.Ignore())
            .ForMember(x => x.CreatedAt, o => o.Ignore());

        CreateMap<Teacher, TeacherDto>();
        CreateMap<TeacherCreateDto, Teacher>().ForMember(x => x.Id, o => o.Ignore());
        CreateMap<TeacherUpdateDto, Teacher>().ForMember(x => x.Id, o => o.Ignore());

        CreateMap<Course, CourseDto>()
            .ForMember(d => d.TeacherName, o => o.MapFrom(s => s.Teacher == null ? null : s.Teacher.FirstName + " " + s.Teacher.LastName));
        CreateMap<CourseCreateDto, Course>().ForMember(x => x.Id, o => o.Ignore())
            .ForMember(x => x.CreatedAt, o => o.MapFrom(_ => DateTime.UtcNow));
        CreateMap<CourseUpdateDto, Course>().ForMember(x => x.Id, o => o.Ignore())
            .ForMember(x => x.CreatedAt, o => o.Ignore());

        CreateMap<Enrollment, EnrollmentDto>()
            .ForMember(d => d.StudentName, o => o.MapFrom(s => s.Student == null ? null : s.Student.FirstName + " " + s.Student.LastName))
            .ForMember(d => d.CourseName, o => o.MapFrom(s => s.Course == null ? null : s.Course.Name));
        CreateMap<EnrollmentCreateDto, Enrollment>()
            .ForMember(x => x.Id, o => o.Ignore())
            .ForMember(x => x.EnrollmentDate, o => o.MapFrom(_ => DateTime.UtcNow))
            .ForMember(x => x.Grade, o => o.Ignore());
    }
}
