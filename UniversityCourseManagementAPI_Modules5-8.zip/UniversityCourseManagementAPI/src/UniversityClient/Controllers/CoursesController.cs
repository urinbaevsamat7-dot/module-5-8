using Microsoft.AspNetCore.Mvc;
using UniversityClient.Services;

namespace UniversityClient.Controllers;

public sealed class CoursesController(CourseApiClient apiClient, ILogger<CoursesController> logger) : Controller
{
    public async Task<IActionResult> Index(CancellationToken ct)
    {
        var (courses, error) = await apiClient.GetCoursesAsync(ct);
        ViewBag.ApiError = error;
        return View(courses);
    }

    public async Task<IActionResult> Details(int id, CancellationToken ct)
    {
        var (course, error, status) = await apiClient.GetCourseAsync(id, ct);
        if (course is not null) return View(course);
        if (status == System.Net.HttpStatusCode.NotFound) return NotFound(error);
        ViewBag.ApiError = error;
        logger.LogWarning("Could not load course details for ID {CourseId}", id);
        return View("ApiError");
    }

    public IActionResult Error() => View("ApiError");
}
