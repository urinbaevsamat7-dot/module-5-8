using UniversityClient.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient<CourseApiClient>(client =>
{
    var baseUrl = builder.Configuration["UniversityApi:BaseUrl"];
    if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var uri))
        throw new InvalidOperationException("Configure UniversityApi:BaseUrl in appsettings.json with the API's base address.");
    client.BaseAddress = uri;
    client.Timeout = TimeSpan.FromSeconds(8);
});

var app = builder.Build();
if (!app.Environment.IsDevelopment()) app.UseExceptionHandler("/Courses/Error");
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name: "default", pattern: "{controller=Courses}/{action=Index}/{id?}");
app.Run();
