using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using UniversityClient.Models;

namespace UniversityClient.Services;

public sealed class CourseApiClient(HttpClient httpClient, IConfiguration configuration, ILogger<CourseApiClient> logger)
{
    private readonly string _coursesPath = (configuration["UniversityApi:CoursesPath"] ?? "api/v1/courses").TrimStart('/');
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true };

    public async Task<(IReadOnlyList<CourseViewModel> Courses, string? Error)> GetCoursesAsync(CancellationToken ct)
    {
        try
        {
            using var response = await httpClient.GetAsync(_coursesPath, ct);
            if (!response.IsSuccessStatusCode)
                return (Array.Empty<CourseViewModel>(), await ReadHttpErrorAsync(response, ct));
            var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<List<CourseViewModel>>>(JsonOptions, ct);
            return envelope?.IsSuccess == true && envelope.Result is not null
                ? (envelope.Result, null)
                : (Array.Empty<CourseViewModel>(), envelope?.ErrorMessage ?? "The API returned an unexpected response.");
        }
        catch (HttpRequestException ex)
        {
            logger.LogWarning("University API connection failed: {Message}", ex.Message);
            return (Array.Empty<CourseViewModel>(), "The University API is unavailable. Start the API and check UniversityApi:BaseUrl.");
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested)
        {
            return (Array.Empty<CourseViewModel>(), "The University API request timed out. Try again shortly.");
        }
        catch (JsonException)
        {
            return (Array.Empty<CourseViewModel>(), "The University API returned invalid JSON.");
        }
    }

    public async Task<(CourseViewModel? Course, string? Error, HttpStatusCode? Status)> GetCourseAsync(int id, CancellationToken ct)
    {
        try
        {
            using var response = await httpClient.GetAsync($"{_coursesPath}/{id}", ct);
            if (!response.IsSuccessStatusCode)
                return (null, await ReadHttpErrorAsync(response, ct), response.StatusCode);
            var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<CourseViewModel>>(JsonOptions, ct);
            return envelope?.IsSuccess == true && envelope.Result is not null
                ? (envelope.Result, null, response.StatusCode)
                : (null, envelope?.ErrorMessage ?? "The API returned an unexpected response.", response.StatusCode);
        }
        catch (HttpRequestException ex)
        {
            logger.LogWarning("University API connection failed: {Message}", ex.Message);
            return (null, "The University API is unavailable. Start the API and check UniversityApi:BaseUrl.", null);
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested)
        {
            return (null, "The University API request timed out. Try again shortly.", null);
        }
        catch (JsonException)
        {
            return (null, "The University API returned invalid JSON.", null);
        }
    }

    private static async Task<string> ReadHttpErrorAsync(HttpResponseMessage response, CancellationToken ct)
    {
        try
        {
            var envelope = await response.Content.ReadFromJsonAsync<ApiEnvelope<JsonElement>>(JsonOptions, ct);
            return envelope?.ErrorMessage ?? $"The API returned HTTP {(int)response.StatusCode} ({response.ReasonPhrase}).";
        }
        catch (JsonException)
        {
            return $"The API returned HTTP {(int)response.StatusCode} ({response.ReasonPhrase}).";
        }
    }
}
