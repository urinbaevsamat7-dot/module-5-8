-- Optional seed script for an already migrated PostgreSQL database.
-- Run against UniversityCourseManagementDb after starting the API once (migrations are applied automatically).
-- Passwords/users/roles are deliberately not inserted here; use ASP.NET Core Identity/UserManager.

INSERT INTO "Teachers" ("FirstName", "LastName", "Email", "Department")
VALUES
  ('Aigerim', 'Sadykova', 'a.sadykova@university.example', 'Software Engineering'),
  ('Daniyar', 'Omarov', 'd.omarov@university.example', 'Information Security')
ON CONFLICT ("Email") DO NOTHING;

INSERT INTO "Students" ("FirstName", "LastName", "Email", "BirthDate", "CreatedAt")
VALUES
  ('Alex', 'Smith', 'alex.smith@example.com', TIMESTAMPTZ '2003-05-12 00:00:00+00', now()),
  ('Dana', 'Kim', 'dana.kim@example.com', TIMESTAMPTZ '2004-02-03 00:00:00+00', now())
ON CONFLICT ("Email") DO NOTHING;

INSERT INTO "Courses" ("Name", "Description", "Credits", "TeacherId", "CreatedAt")
SELECT 'Web Services Development', 'REST API design and implementation.', 5, t."Id", now()
FROM "Teachers" t WHERE t."Email" = 'a.sadykova@university.example'
AND NOT EXISTS (SELECT 1 FROM "Courses" c WHERE c."Name" = 'Web Services Development');

INSERT INTO "Courses" ("Name", "Description", "Credits", "TeacherId", "CreatedAt")
SELECT 'Application Security', 'Secure application development fundamentals.', 4, t."Id", now()
FROM "Teachers" t WHERE t."Email" = 'd.omarov@university.example'
AND NOT EXISTS (SELECT 1 FROM "Courses" c WHERE c."Name" = 'Application Security');

INSERT INTO "Enrollments" ("StudentId", "CourseId", "EnrollmentDate", "Grade")
SELECT s."Id", c."Id", now(), 92
FROM "Students" s CROSS JOIN "Courses" c
WHERE s."Email" = 'alex.smith@example.com' AND c."Name" = 'Web Services Development'
AND NOT EXISTS (SELECT 1 FROM "Enrollments" e WHERE e."StudentId" = s."Id" AND e."CourseId" = c."Id");
