# University Course Management API — Задание 1 + Задание 2 (модули 1–8)

Проект для CSE5032 «Разработка веб-сервисов». Основной API и отдельный ASP.NET Core MVC-клиент используют .NET 8 и PostgreSQL. Клиент получает данные только через HTTP с помощью `IHttpClientFactory`, а не обращается к базе API напрямую.

> Перед сдачей обязательно выполните `dotnet build` и пройдите тестовые сценарии на своём компьютере. В текущей среде .NET SDK недоступен, поэтому архив содержит исходный код и миграцию, но сборка здесь не запускалась.

## Что реализовано

### Модули 1–4: базовый API
- CRUD студентов, преподавателей, курсов и записей на курсы.
- EF Core, PostgreSQL, Repository Pattern, сервисный слой, DI, DTO, AutoMapper.
- Валидация, единый `ReturnResult<T>`, централизованная обработка ошибок и логирование.

### Модули 5–8: безопасность и клиент
- ASP.NET Core Identity с EF Core: защищённое хеширование паролей, уникальное имя пользователя, требования к паролю и блокировка после 5 неудачных входов на 15 минут.
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`.
- JWT Bearer: подпись, issuer, audience, срок действия Access Token (20 минут по умолчанию), пользовательские claims и роли.
- Роли `Admin`, `Teacher`, `Student`; публичная регистрация назначает только `Student`.
- `GET /api/admin/users`, `PUT /api/admin/users/{userId}/role`, `POST /api/admin/users/{userId}/lockout` для администрирования.
- Защита CRUD-операций; преподаватель может менять оценки только по собственным курсам; студент видит только собственные записи и оценки.
- Версионированные курсы: `/api/v1/courses`, `/api/v2/courses` и варианты по ID. v2 добавляет имя преподавателя и число записанных студентов.
- Swagger с двумя OpenAPI-документами и Bearer JWT.
- Именованная CORS-политика `UniversityClientPolicy` с двумя origin из конфигурации.
- Отдельный MVC-клиент `UniversityClient`, typed `HttpClient` через `IHttpClientFactory`, список/детали курсов и обработка сетевых ошибок, тайм-аутов и неуспешных HTTP-ответов.
- Миграции EF Core и SQL seed-скрипт для PostgreSQL.

## Требования
- .NET 8 SDK
- PostgreSQL 14+ (или совместимая версия)
- PowerShell или терминал
- Для тестов удобно использовать Swagger, Postman или расширение REST Client для файлов `.http`

## Настройка секретов (Windows PowerShell)

Не храните реальный пароль БД, пароль администратора или JWT signing key в Git. В репозитории `appsettings.json` содержит только `Password=CHANGE_ME`.

Из корня репозитория выполните команды, подставив пароль локального PostgreSQL:

```powershell
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "Host=localhost;Port=5432;Database=UniversityCourseManagementDb;Username=postgres;Password=ВАШ_ПАРОЛЬ" --project .\src\UniversityApi\UniversityApi.csproj
$jwtKey = [Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(64))
dotnet user-secrets set "Jwt:Key" $jwtKey --project .\src\UniversityApi\UniversityApi.csproj
dotnet user-secrets set "SeedAdmin:UserName" "admin" --project .\src\UniversityApi\UniversityApi.csproj
dotnet user-secrets set "SeedAdmin:Email" "admin@example.com" --project .\src\UniversityApi\UniversityApi.csproj
dotnet user-secrets set "SeedAdmin:Password" "REPLACE_WITH_A_STRONG_PASSWORD" --project .\src\UniversityApi\UniversityApi.csproj
```

Последнюю команду замените своим паролем. Пароль должен содержать минимум 10 символов, заглавную и строчную буквы, цифру и специальный символ. Эти значения хранятся в локальном User Secrets и не попадают в Git.

В Development, если `Jwt:Key` не задан, API создаёт временный случайный ключ на время процесса. После перезапуска выданные этим ключом токены перестанут проходить проверку. Для стабильной демонстрации используйте User Secrets, как показано выше.

## Запуск API

```powershell
dotnet restore .\src\UniversityApi\UniversityApi.csproj
dotnet build .\src\UniversityApi\UniversityApi.csproj
dotnet run --project .\src\UniversityApi\UniversityApi.csproj
```

API слушает `http://localhost:5000`; Swagger: <http://localhost:5000/swagger>. При первом запуске EF Core применяет миграции, добавляет базовые демонстрационные данные (если таблицы пусты) и создаёт роли. Если у вас база из старой версии, созданная через `EnsureCreated`, код пытается зарегистрировать исходную миграцию в `__EFMigrationsHistory`, после чего применяет миграцию Identity. Перед важной базой сделайте резервную копию.

Если база новая, приложение применит `InitialCreate` и `AddIdentityAndSecurity`. Команды EF CLI при необходимости:

```powershell
dotnet tool install --global dotnet-ef --version 8.0.11
dotnet ef migrations list --project .\src\UniversityApi\UniversityApi.csproj
dotnet ef database update --project .\src\UniversityApi\UniversityApi.csproj
```

## Запуск отдельного MVC-клиента

В отдельном терминале из корня репозитория:

```powershell
dotnet restore .\src\UniversityClient\UniversityClient.csproj
dotnet run --project .\src\UniversityClient\UniversityClient.csproj
```

Откройте <http://localhost:5100>. Адрес API задаётся в `src/UniversityClient/appsettings.json` в `UniversityApi:BaseUrl`; путь к курсам задаётся в `UniversityApi:CoursesPath`. Если API запущен на другом адресе, измените конфигурацию, а не исходный код клиента.

CORS разрешает `http://localhost:3000` и `http://localhost:5100`. Список задаётся в `src/UniversityApi/appsettings.json` в `Cors:AllowedOrigins`.

## Быстрый сценарий демонстрации

1. В Swagger выполните `POST /api/auth/login` для `admin` с паролем, который вы задали через User Secrets.
2. Скопируйте `result.accessToken`, нажмите **Authorize** в Swagger и вставьте токен без префикса `Bearer`.
3. Как Admin проверьте `GET /api/admin/users`, создание преподавателя через `POST /api/Teachers` и CRUD курсов.
4. Зарегистрируйте обычного пользователя через `POST /api/auth/register`. Он автоматически получает только роль `Student`, без административных прав.
5. Войдите новым пользователем через `/api/auth/login`, используйте токен и проверьте `/api/auth/me` и `/api/Enrollments/mine`.
6. Чтобы подготовить преподавателя, создайте/используйте существующую запись `Teacher`, затем администратором вызовите `PUT /api/admin/users/{userId}/role` с `{"role":"Teacher","teacherId":1}`. Повторно войдите этим пользователем, чтобы получить новый токен с актуальными claims.
7. Проверьте анонимный `GET /api/v1/courses` и `GET /api/v2/courses`, затем сравните поля ответа. v2 включает `teacherName` и `enrolledStudentCount`.
8. Запустите MVC-клиент и откройте список/детали курса.

## Аутентификация и авторизация

- **Аутентификация** отвечает на вопрос «кто пользователь?». В этом проекте логин проверяет пароль средствами ASP.NET Core Identity, после чего выдаётся подписанный JWT. Middleware проверяет подпись, issuer, audience и срок действия.
- **Авторизация** отвечает на вопрос «что этому пользователю разрешено?». `[Authorize]`, роли и политики ограничивают операции после успешной аутентификации.
- **Claims** — утверждения о пользователе внутри токена: идентификатор, имя, роль и, когда есть связь, `studentId`/`teacherId`.
- Одной роли `Teacher` недостаточно: endpoint оценки дополнительно сравнивает `teacherId` из токена с преподавателем курса. Аналогично студент получает только записи, где `StudentId` совпадает с его профилем.

Ожидаемые статусы: анонимный доступ к защищённому endpoint — `401`; пользователь с действительным токеном, но без нужной роли/доступа к ресурсу — `403`; корректный запрос — `200`/`201`. Для сценария «Student пытается удалить курс» правильный результат для аутентифицированного Student — `403 Forbidden`, а не `401`, поскольку пользователь уже аутентифицирован.

## Ключевые маршруты

| Метод | Маршрут | Доступ |
|---|---|---|
| POST | `/api/auth/register` | Анонимный; назначает Student |
| POST | `/api/auth/login` | Анонимный; выдаёт JWT |
| GET | `/api/auth/me` | Любой аутентифицированный пользователь |
| GET | `/api/Courses` | Публичный legacy endpoint |
| GET | `/api/v1/courses` и `/api/v1/courses/{id}` | Публичный v1 |
| GET | `/api/v2/courses` и `/api/v2/courses/{id}` | Публичный v2 с расширенным DTO |
| POST/PUT/DELETE | `/api/Courses` | Только Admin |
| POST/PUT/DELETE | `/api/Students`, `/api/Teachers`, `/api/Enrollments` | Только Admin |
| GET | `/api/Enrollments/mine` | Student: свои записи; Teacher: записи собственных курсов; Admin: все |
| PATCH | `/api/Enrollments/{id}/grade` | Admin или Teacher своего курса |
| GET/PUT/POST | `/api/admin/users...` | Только Admin |

## Миграции и тестовые данные

- Миграции находятся в `src/UniversityApi/Migrations`.
- `database/seed-postgresql.sql` — необязательный SQL-скрипт для базовых записей преподавателей, студентов, курсов и enrollment. Основные демо-данные также добавляются `DbSeeder` при пустых таблицах.
- Пароли нельзя добавлять SQL-скриптом: Identity должен создавать аккаунты через `UserManager`, чтобы пароль сохранялся в виде безопасного хеша. Роль Admin создаётся из локальных настроек `SeedAdmin`.
- `scripts/security-demo.http` содержит примеры запросов для REST Client. После login скопируйте токен в переменную `@token`.

## Перед сдачей

```powershell
dotnet build .\src\UniversityApi\UniversityApi.csproj
dotnet build .\src\UniversityClient\UniversityClient.csproj
```

Проверьте все сценарии безопасности, версии API и клиентское приложение. Не коммитьте User Secrets, `bin/`, `obj/`, реальные connection strings и токены.
