# Security test scenarios for the practical defense

Run the API and open Swagger at `http://localhost:5000/swagger`. Use the **Authorize** button to set `Bearer` tokens. The token returned by login is under `result.accessToken`.

| # | Test | Expected result |
|---:|---|---|
| 1 | Anonymous `GET /api/v1/courses` | `200 OK` |
| 2 | Anonymous `POST /api/Courses` | `401 Unauthorized` |
| 3 | `POST /api/auth/login` with wrong password | `401`, no access token |
| 4 | Login with correct credentials | `200`, short-lived JWT returned |
| 5 | Use expired, modified, wrong-issuer or wrong-audience token | `401 Unauthorized` |
| 6 | Authenticated Student calls `DELETE /api/Courses/{id}` | `403 Forbidden` (authenticated but lacks permission) |
| 7 | Teacher updates grade for an enrollment on their linked course | `200 OK` |
| 8 | Teacher updates grade for an enrollment on another teacher's course | `403 Forbidden` |
| 9 | Student requests another student's enrollment ID | `403 Forbidden` |
| 10 | Admin assigns Teacher role and `teacherId` to another user | `200 OK`; sign in again to refresh claims |
| 11 | Student calls `PUT /api/admin/users/{userId}/role` to self-promote | `403 Forbidden` |
| 12 | `GET /api/v1/courses` and `GET /api/v2/courses` | Both return data; v2 includes `teacherName` and `enrolledStudentCount` |

The assignment handout lists scenario 6 as `401`. Under standard HTTP semantics, a valid Student token results in `403`; `401` is for a missing or invalid token. This implementation follows the distinction explicitly required earlier in the assignment: unauthenticated is `401`, authenticated but unauthorized is `403`.

## Prepare a Teacher test account

1. Register a test account through `POST /api/auth/register` and sign in once to obtain its user ID from `GET /api/admin/users` (using the Admin token).
2. Choose an existing `Teacher` row (for example ID `1`) or create one as Admin.
3. Call `PUT /api/admin/users/{userId}/role` with body `{"role":"Teacher","teacherId":1}`.
4. Sign in as that account again. JWTs are snapshots of claims, so the old token does not gain the new role automatically.
5. Create or identify a course assigned to that teacher and an enrollment on it; test grade updates on both owned and foreign courses.

## Prepare a Student privacy test

Register two distinct students, enroll both in courses as Admin, and sign in as Student A. `GET /api/Enrollments/mine` must return only Student A's records. Requesting Student B's enrollment by ID must return `403`.
