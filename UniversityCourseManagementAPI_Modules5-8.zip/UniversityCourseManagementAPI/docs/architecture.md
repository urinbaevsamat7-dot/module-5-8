# Архитектура и безопасность

```mermaid
flowchart TD
    Client[Swagger / Postman / MVC Client] -->|HTTP JSON + optional Bearer JWT| Cors[CORS policy]
    Cors --> AuthN[Authentication Middleware]
    AuthN --> AuthZ[Authorization Middleware: roles, policies, ownership]
    AuthZ --> Controllers[API Controllers / v1 / v2]
    Controllers --> Services[Services / business rules]
    Services --> Repositories[Repository interfaces / implementations]
    Repositories --> EF[EF Core + ApplicationDbContext]
    EF --> DB[(PostgreSQL)]
    Identity[ASP.NET Core Identity / UserManager / RoleManager] --> DB
    AuthN --> Jwt[JWT validation: signature, issuer, audience, expiry]
    Login[POST /api/auth/login] --> Identity
    Identity --> Token[TokenService creates short-lived JWT]
    Token --> Client
    Error[Exception handling middleware] -. wraps API pipeline .-> Controllers
```

## Порядок обработки запроса

1. CORS проверяет browser-origin для cross-origin запросов.
2. Authentication Middleware читает `Authorization: Bearer <token>` и проверяет JWT.
3. Authorization Middleware проверяет роль/политику.
4. Контроллер выполняет проверку принадлежности ресурса: `teacherId` должен совпасть с владельцем курса, `studentId` — с владельцем оценки.
5. Сервис и репозиторий обращаются к PostgreSQL через EF Core.
6. Результат возвращается через DTO и `ReturnResult<T>`; ошибки не раскрывают внутренние исключения.

## Аутентификация и авторизация

- Аутентификация устанавливает личность пользователя по Identity и JWT.
- Авторизация проверяет разрешённые действия на основе роли и контекста ресурса.
- JWT содержит user ID, username, роли и привязку к профилю Student/Teacher, если она назначена.
- Регистрация не принимает роль из запроса: новый аккаунт получает только `Student`.
- Пароль хранится как хеш, созданный ASP.NET Core Identity; секрет подписи JWT задаётся вне исходного кода.
