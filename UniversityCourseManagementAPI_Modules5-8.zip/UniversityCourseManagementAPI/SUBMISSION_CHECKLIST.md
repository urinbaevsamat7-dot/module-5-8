# Чек-лист перед сдачей: CSE5032, модули 1–8

## Подготовка
- [ ] Установить .NET 8 SDK и PostgreSQL.
- [ ] Настроить `ConnectionStrings:DefaultConnection`, `Jwt:Key` и SeedAdmin через User Secrets или переменные окружения. Не коммитить секреты.
- [ ] Выполнить `dotnet restore` и `dotnet build` для `UniversityApi` и `UniversityClient`.
- [ ] Запустить API на `http://localhost:5000`, открыть Swagger и проверить миграции.
- [ ] Запустить MVC-клиент на `http://localhost:5100`.

## Базовый API
- [ ] CRUD студентов, преподавателей, курсов и записей на курсы.
- [ ] Валидация, дубликаты email/enrollment, корректные `400`, `404`, `409`.

## Безопасность
- [ ] Регистрация создаёт пользователя с ролью Student, но не Admin.
- [ ] Login выдаёт JWT; проверить неверный пароль, неверный/просроченный токен и срок действия.
- [ ] Проверить `GET /api/auth/me` и Bearer-кнопку Swagger.
- [ ] Проверить роли Admin, Teacher и Student, назначение роли только администратором.
- [ ] Проверить: анонимный write -> `401`; недостаточные права/чужой ресурс -> `403`.
- [ ] Проверить, что Teacher может менять оценку только в своём курсе, Student видит только свои оценки.
- [ ] Проверить блокировку после 5 неудачных входов.

## Версии и клиент
- [ ] `GET /api/v1/courses` и `/api/v1/courses/{id}` сохраняют контракт v1.
- [ ] `GET /api/v2/courses` и `/api/v2/courses/{id}` возвращают `teacherName` и `enrolledStudentCount`.
- [ ] Проверить оба документа Swagger/OpenAPI.
- [ ] Проверить MVC-клиент: список, детали курса, отключённый API, timeout и HTTP-ошибки.
- [ ] Проверить именованную CORS-политику `UniversityClientPolicy`.

## Материалы для преподавателя
- [ ] Обновить GitHub репозиторий и приложить этот ZIP.
- [ ] Приложить миграции, PostgreSQL seed script, `scripts/security-demo.http`, README и `docs/architecture.md`.
- [ ] Подготовить скриншоты Swagger и клиента после локального успешного запуска.
- [ ] Убедиться, что в Git нет реальных паролей, JWT, ключей подписи, `bin/` и `obj/`.
